#pragma once
#include <string>
#include <iostream>
using std::string;
using std::cin;
using std::cout;
using std::endl;

class AVLTreeNode {
public:
	// Should have attributes named:
	// parent - pointer to parent
	// left - pointer to left child
	// right - pointer to right child
	// word - node's string data
	// count - number of times the word appears
	// height - node's height

	string word;
	unsigned int count;
	unsigned int height;
	AVLTreeNode* parent;
	AVLTreeNode* left;
	AVLTreeNode* right;

	// Constructors ...
	AVLTreeNode(string word)
    : word(word), count(1), height(0), parent(nullptr), left(nullptr), right(nullptr) {} // set height to 0 and count to one since we created the node with word. 

};

// Wordlist class
class Wordlist
{
private:
	// Class attributes go here
	// Your class MUST have a root node named root (below)
	AVLTreeNode* root; // DO NOT REMOVE

	// helper methods 

	// Deep Copy

	AVLTreeNode* copyTree(AVLTreeNode* node);

	// Operator= helper function to clear memory.

	void clearTree(AVLTreeNode* node);

	// height finder

	int getHeight(AVLTreeNode* node);

	// balance factor

	int getBalanceFactor(AVLTreeNode* node);

	// rotation helpers

	AVLTreeNode* rightRotate(AVLTreeNode* y);

	AVLTreeNode* leftRotate(AVLTreeNode* x);

	// insert helper

	AVLTreeNode* inserter(AVLTreeNode*& node, string word);


	// getCount helepr

	AVLTreeNode* finder(AVLTreeNode* node, string word) const; 

	// counter for differentWords

	int diffCounter(AVLTreeNode* node) const;

	// counter for total words

	int totalCounter(AVLTreeNode* node) const;

	// helper method for most frequent

	void mostFreq_h(AVLTreeNode* nopde, string& mostW, unsigned int& count) const;

	// singleton helper

	int singletonH(AVLTreeNode* node) const;

	//printWords helper

	void printWordsH(AVLTreeNode* node, int& index) const;

	// height adjuster

	int h_adjust(int a, int b);

	// Remove method helper

	AVLTreeNode* removeH(AVLTreeNode* node, string word, bool& found);

	// finding the min node in trees

	AVLTreeNode* getMinNode(AVLTreeNode* node);

public:
	// public methods go here
	// default constructor
	Wordlist() : root(nullptr) {}

	// file constructor

	Wordlist(string filename);

	// copy constructor

	Wordlist(const Wordlist& wl);

	// operator=

	Wordlist& operator=(const Wordlist & wl);

	// deconstructor

	~Wordlist();

	// insert

	void insert(string word);

	// remove

	bool remove(string word);

	// getCount

	int getCount(string word) const;

	// contains

	bool contains(string word) const;

	// differentWords

	int differentWords() const;

	// totalWords

	int totalWords() const;

	// mostFrequent

	string mostFrequent() const;

	// singletons

	int singletons() const;

	// print words

	void printWords() const;

	// Prints useful statistics about the word list
	void printStatistics() const;

	// Returns the root of the AVL tree
	AVLTreeNode* getRoot() const { return root; }; // DO NOT REMOVE
};
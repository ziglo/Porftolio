#include "Wordlist.h"
#include <iomanip>
#include <fstream>
using std::setprecision;
using std::fixed;
using std::ifstream; // if/of stream for file reading/writing.
using std::ofstream;


// File Constructor

Wordlist::Wordlist(string filename) : root (nullptr) {
	ifstream file; // ifstream to read file
	file.open(filename); // open filename.
	string next;// initialize string variable next.

	while (file >> next) {
		insert(next); // utilize insert method to insert 'next' into AVL Tree nodes.
	}
	file.close(); // close file. 
}

// Copy Constructor

Wordlist::Wordlist(const Wordlist& wl) : root(nullptr) {
	// initalize root to be copied by calling copyTree helper method. 
	root = copyTree(wl.root);
}

// overload assignment operator

Wordlist& Wordlist::operator=(const Wordlist& wl){
	// Self assignment check.
	if (this == &wl){
		return *this;
	}

	// deallocate all existing dynamic memory.
   	clearTree(root);
	root = nullptr;

	// deep copy.
	root = copyTree(wl.root);

	return *this;
    
}

// destructor

Wordlist::~Wordlist(){
	// uitilize clear tree method.
	clearTree(root);
	root = nullptr;
}

// insert method

void Wordlist::insert(string word){
	// check if tree is empty if so, create root node with word. 
	if (root == nullptr){
		root = new AVLTreeNode(word);
		return;
	}

	// call helper function to insert the word
	inserter(root, word);
}

bool Wordlist::remove(string word){
	// set word_found to false, will be updated if found in removeH helper method.
	bool word_found = false;
	root = removeH(root, word, word_found);
	return word_found;
}

// getCount method

int Wordlist::getCount(string word) const{
	// use finder helper method to locate node containing the word
	AVLTreeNode* node = finder(root,word);
	// if node exists return its count
	if(node != nullptr){
		return node->count;
	}
	return 0;
}

// contains method

bool Wordlist::contains(string word) const{
	// utilize getCount method.
	return getCount(word) > 0;
}

// differentWords method.

int Wordlist::differentWords() const{
	// call diffCounter with root as starting point.
	return diffCounter(root);
}

// totalWords method.

int Wordlist::totalWords() const{
	// call totalCounter helper with root as starting point. 
	return totalCounter(root);
}

// mostFrequent method.

string Wordlist::mostFrequent() const{
	// if tree is empty. 
	if (root == nullptr){
		throw std::invalid_argument("no words exists.");
	}

	// initialize variables to store most frequent word and its count
	string freqWord;
	unsigned int count = 0;

	// call helper method to find most frequent word
	mostFreq_h(root, freqWord, count);

	return freqWord + " " + std::to_string(count);
}

// singleton method

int Wordlist::singletons() const{
	// call singleton helper method with root as starting point.
	return singletonH(root);
}

// printWords method.

void Wordlist::printWords() const {
	// create index variable for indexing to print i.e. 1. 2. etc..
	int index = 1;
	// call helper method to print.
	printWordsH(root, index);
}

// Prints useful statistics about the word list
void Wordlist::printStatistics() const
{
	// print number of different words
	cout << "Number of different words: " << differentWords() << endl;
	// print total word count
	cout << "    Total number of words: " << totalWords() << endl;
	// print most frequent word and its count
	cout << "       Most frequent word: " << mostFrequent() << endl;
	// print number and percentage of singletons
	cout << "     Number of singletons: " << singletons()
		<< setprecision(0) << fixed
		<< " (" << 100.0 * singletons() / differentWords() << "%)"
		<< endl;
}

// Helper functions

// Copy tree

AVLTreeNode* Wordlist::copyTree(AVLTreeNode* node){
	// base case: if node is null
	if (node == nullptr){
		return nullptr;
	}

	// create new node with same word
	AVLTreeNode* copyNode = new AVLTreeNode(node -> word);
	// copy count and height
	copyNode->count = node->count;
	copyNode->height = node->height;

	// recursively copy left and right subtrees
	copyNode->left = copyTree(node->left);
	copyNode->right = copyTree(node->right);

	// set parent pointers for left child
	if(copyNode -> left){
		copyNode->left->parent = copyNode;
	}

	// set parent pointers for right child
	if(copyNode->right){
		copyNode->right->parent = copyNode;
	}

	return copyNode;
}

// clearTree (clears memory)

void Wordlist::clearTree(AVLTreeNode* node){
	// base case: if node is null
	if (node == nullptr){
		return;
	}

	// recursively clear left and right subtrees
	clearTree(node->left);
	clearTree(node->right);

	// delete current node
	delete node;
}

// getHeight method

int Wordlist::getHeight(AVLTreeNode* node){
	// if empty return -1.
	if (node == nullptr){
		return -1;
	}
	return node->height; // returns the height of the node.
}

// Balance Factor Method

int Wordlist::getBalanceFactor(AVLTreeNode* node){
	// if empty returns 0.
	if (node == nullptr){
		return 0;
	}
	// using balance fact or formula, returns balance factor. 
	return getHeight(node->left) - getHeight(node->right);
}

// rotation helper methods

AVLTreeNode* Wordlist::leftRotate(AVLTreeNode* x) {
    // store right child of x as y == new root 
    AVLTreeNode* y = x->right;
    // move y left child to be x right child
    x->right = y->left;

    // update parent pointer of y old left child if it exists
    if (y->left != nullptr) {
        y->left->parent = x;
    }

    // set y parent to x parent
    y->parent = x->parent;

    // update parent child pointer or root if x was root
    if (x->parent == nullptr) {
        root = y;
    } else if (x == x->parent->left) {
        x->parent->left = y;
    } else {
        x->parent->right = y;
    }

    // make x the left child of y
    y->left = x;
    x->parent = y;

    // update heights of affected nodes
    x->height = 1 + h_adjust(getHeight(x->left), getHeight(x->right));
    y->height = 1 + h_adjust(getHeight(y->left), getHeight(y->right));

    // return new root of subtree
    return y;
}

AVLTreeNode* Wordlist::rightRotate(AVLTreeNode* y) {
    // store left child of y as x == root
	// same logic as leftRotate, just accommodated for rigth rotation. 
    AVLTreeNode* x = y->left;
   
    y->left = x->right;


    if (x->right != nullptr) {
        x->right->parent = y;
    }

    x->parent = y->parent;

    if (y->parent == nullptr) {
        root = x;
    } else if (y == y->parent->left) {
        y->parent->left = x;
    } else {
        y->parent->right = x;
    }

    x->right = y;
    y->parent = x;


    y->height = 1 + h_adjust(getHeight(y->left), getHeight(y->right));
    x->height = 1 + h_adjust(getHeight(x->left), getHeight(x->right));

    return x;
}

// insert helper method

AVLTreeNode* Wordlist::inserter(AVLTreeNode*& node, string word) {
	// if empty just create new AVLTree node. 
    if (node == nullptr) {
        return new AVLTreeNode(word);
    }

	// condition checks to see where to insert node.
    if (word < node->word) {
        AVLTreeNode* leftChild = inserter(node->left, word);
        node->left = leftChild;
        if (leftChild) leftChild->parent = node;  // Set parent pointer
    } else if (word > node->word) {
        AVLTreeNode* rightChild = inserter(node->right, word);
        node->right = rightChild;
        if (rightChild) rightChild->parent = node;  // Set parent pointer
    } else {
        node->count++;
        return node;
    }

    // Update the height of the current node
    node->height = 1 + h_adjust(getHeight(node->left), getHeight(node->right));

    // Check balance factor and perform rotations
    int balanceFactor = getBalanceFactor(node);

    // Left heavy
    if (balanceFactor > 1) {
        if (word < node->left->word) {  // Left-Left case
            return rightRotate(node);
        } else {  // Left-Right case
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }
    }

    // Right heavy
    if (balanceFactor < -1) {
        if (word > node->right->word) {  // Right-Right case
            return leftRotate(node);
        } else {  // Right-Left case
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }
    }

    return node;
}

// getCount helper method

AVLTreeNode* Wordlist::finder(AVLTreeNode*node, string word) const{
	// if node is null or word is found == base case. 
	if (node == nullptr){
		return nullptr;
	}
	// search left subtree
	if(word < node->word){
		return finder(node->left, word);
	} 
	// search right subtree
	else if ( word > node->word){
		return finder(node->right, word);
	} 
	// word found then return
	else {
		return node;
	}
}

// diffCounter helper method

int Wordlist::diffCounter(AVLTreeNode* node) const{
	//if node is empty, base case 
	if(node == nullptr){
		return 0;
	}
	// count current node plus all different words in left and right subtrees
	return 1 + diffCounter(node->left) + diffCounter(node->right);
}

// totalCounter

int Wordlist::totalCounter(AVLTreeNode* node) const{
	// base case nullptr, 0  same as diffCOunter.. 
	if(node == nullptr){
		return 0;
	}
	// add current node's count plus all counts in left and right subtrees
	return getCount(node->word) + totalCounter(node->left) + totalCounter(node->right);
}

// most frequent word helper method

void Wordlist::mostFreq_h(AVLTreeNode* node, string& word, unsigned int& count) const{
	// if node is null then return
	if (node == nullptr){
		return;
	}

	// update both count and word if condition true.
	if(node->count > count){
		count = node->count;
		word = node->word;
	}
	// take smaller word
	else if (node->count == count){
		if(node->word < word){
			word = node->word;
		}
	}

	// recursive check left and right subtrees
	mostFreq_h(node->left, word, count);
	mostFreq_h(node->right, word, count);
}

int Wordlist::singletonH(AVLTreeNode* node) const{
	if (node == nullptr){
		return 0;
	}

	// initialize counter
	int counter = 0;

	// increment counter if node has count of 1.
	if (node->count == 1){
		counter = 1;
	}

	// recursively add singletons from left and right subtrees
	counter += singletonH(node->left);
	counter += singletonH(node->right);

	return counter;
}

// Printword helper

void Wordlist::printWordsH(AVLTreeNode* node, int& index) const {

	if (node == nullptr) return;

	// traverse left subtree first
	printWordsH(node->left, index);
	// condition to guarantee 0 count words aren't printed just in case. 
	if (node->count > 0) { 
		cout << index << ". " << node->word << " " << node->count << endl;
	}
	// increment index for next word
	index++;
	// traverse right subtree
	printWordsH(node->right, index);
}

// height adjuster helper method.
int Wordlist::h_adjust(int a, int b){
	// as code showcases, if a is bigger than b the return a if not returns b. 
	if (a > b){
		return a;
	} else {
		return b;
	}		
} 

// GetMinNOde helper method.

AVLTreeNode* Wordlist::getMinNode(AVLTreeNode* node){
	// looks for smallest node, only looks at left since it should be balanced AVL tree.
	while(node->left != nullptr){
		node = node->left;
	}
	return node;
}
// remover helper

AVLTreeNode* Wordlist::removeH(AVLTreeNode* node, string word, bool& found){
    // base case.
    if (node == nullptr){
        return node;
    }

    // recursively search for node to remove
    if (word < node->word){
        node->left = removeH(node->left, word, found);
    } else if (word > node->word){
        node->right = removeH(node->right, word, found);
    } else {
        // set found flag to true, set it to false previously in remove method. 
        found = true;
        
        // if the node has no left child, set temp to node->right and delete node. 
        if (node->left == nullptr){
            AVLTreeNode* temp = node->right;
            delete node;
            return temp;
        } 
        // if the node has no right child, set temp to node->left and delete node.
        else if (node->right == nullptr){
            AVLTreeNode* temp = node->left;
            delete node;
            return temp;
        }

        // case 3: node has two children
        // find smallest value in right subtree
        AVLTreeNode* temp = getMinNode(node->right);
        // copy data from successor
        node->word = temp->word;
        node->count = temp->count;
        // remove successor
        node->right = removeH(node->right, temp->word, found);
    }

    // update height of current node
    node->height = 1 + h_adjust(getHeight(node->left), getHeight(node->right));
    
    // get balance factor to check if rebalancing is needed
    int balance = getBalanceFactor(node);

    // perform rotations if needed to maintain AVL property
    if (balance > 1 && getBalanceFactor(node->left) >= 0) {
        return rightRotate(node);
    }
    if (balance > 1 && getBalanceFactor(node->left) < 0) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }
    if (balance < -1 && getBalanceFactor(node->right) <= 0) {
        return leftRotate(node);
    }
    if (balance < -1 && getBalanceFactor(node->right) > 0) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}
